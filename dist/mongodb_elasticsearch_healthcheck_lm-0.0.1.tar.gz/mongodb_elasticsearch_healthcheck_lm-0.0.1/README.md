# Mongodb and Elasticsearch django healthcheck

- two classes that contains tests for checking the healthcheck of mongo and elasticsearch.
- simply add the classes to the apps.py 